package com.example.csx4109_542_assignment_1_6612054.Model

import kotlinx.serialization.Serializable

@Serializable
data class Detail (
    val name: String,
    val url: String
)